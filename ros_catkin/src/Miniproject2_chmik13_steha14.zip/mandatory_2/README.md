# mandatory_2


To run this repo, you need "video_stabilizer_node" and "video_stream_opencv" modules built by catkin. (use catkin build in your catkin directory)

Additionally you need to place your video file in the directory video_stabilizer_node/data/. The play.launch draws the video from this directory and the video should be called "youtube_test.mp4" else change the path yourself. The video this program is run on, is from the following link. https://www.youtube.com/watch?v=UA1zPvjSbjs You can download this file with a youtube downloader.

the command to launch the nodes, are roslaunch mandatory_2 play.launch

Good luck
